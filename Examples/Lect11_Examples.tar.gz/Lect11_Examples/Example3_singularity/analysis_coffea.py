#!/usr/bin/env python
import datetime
import awkward as ak
import dask_awkward as dak
import hist
from coffea.nanoevents import NanoEventsFactory, NanoAODSchema
from coffea.nanoevents.methods import candidate
import uproot

def main():
    filename = "file://DYJetsToLL_M_50_2022.root"
    
    # Creating events
    events = NanoEventsFactory.from_root(
        {filename: "Events"},
        metadata={"dataset": "DoubleMuon"},
        schemaclass=NanoAODSchema,
    ).events()

    counter1 = dak.num(events, axis=0)

    # Building muon objects
    muons = ak.zip(
        {
            "pt": events.Muon.pt,
            "eta": events.Muon.eta,
            "phi": events.Muon.phi,
            "mass": events.Muon.mass,
            "charge": events.Muon.charge,
        },
        with_name="PtEtaPhiMCandidate",
        behavior=candidate.behavior,
    )

    # Two muons with opposite charge
    cut = (ak.num(muons) == 2) & (ak.sum(muons.charge, axis=1) == 0)
    
    # Calculate invariant mass
    dimuons = muons[cut][:, 0] + muons[cut][:, 1]
    masses = dimuons.mass

    # Flatten table for filling histogram
    masses_flat = ak.flatten(masses, axis=None).compute()

    # Creating and filling histogram
    h_mass = hist.Hist.new.Reg(200, 0, 200, name="x", label="Mass [GeV]").Double()
    h_mass.fill(x=masses_flat)


    with uproot.recreate("output.root") as fOUT:
        now = datetime.datetime.now()
        fOUT[f"produced_{now.strftime('%Y%m%d_%H%M%S')}"] = ""
        fOUT["h_mass"] = h_mass

    print(f"All events:     ",counter1)

if __name__ == "__main__":
    main()
