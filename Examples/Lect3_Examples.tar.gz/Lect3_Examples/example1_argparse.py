#!/usr/bin/env python

import os
import sys

import argparse

# try example1_argparse.py -h

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--par", dest="parameter", default=False, action="store_true", help="Flag to test parameter passing")

    args = parser.parse_args()

    if args.parameter:
        print("Parameter value True")
    else:
        print("Parameter value False")

if __name__=="__main__":
    main()
