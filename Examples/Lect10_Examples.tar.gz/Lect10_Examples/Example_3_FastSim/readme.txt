# Example 3

scram p CMSSW CMSSW_16_0_4_patch1
cd CMSSW_16_0_4_patch1/src
cmsenv
git cms-addpkg Configuration/Generator
scram b -j 8

# Beamspots in Configuration/StandardSequences/python/VtxSmeared.py

cmsDriver.py Configuration/Generator/python/TTbar_13TeV_TuneCUETP8M1_cfi.py \
-s GEN,SIM,RECOBEFMIX,DIGI:pdigi_valid,L1,DIGI2RAW,L1Reco,RECO \
-n 10 \
--conditions auto:run3_mc_GRun \
--datatier AODSIM \
--eventcontent AODSIM \
--geometry DB:Extended \
--era Run3_2026 \
--beamspot DBrealistic \
--fast \
--no_exec \
--fileout file:step3_fast.root

cmsRun TTbar_13TeV_TuneCUETP8M1_cfi_py_GEN_SIM_RECOBEFMIX_DIGI_L1_DIGI2RAW_L1Reco_RECO.py
