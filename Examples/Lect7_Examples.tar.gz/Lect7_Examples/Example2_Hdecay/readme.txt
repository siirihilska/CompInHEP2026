git clone https://gitea.psi.ch/ltpth/HDECAY
cd HDECAY
tar xfvz hdecay.tar.gz
make
run
